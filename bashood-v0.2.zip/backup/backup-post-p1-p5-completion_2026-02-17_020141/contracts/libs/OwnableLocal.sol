// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/// @notice Minimal Ownable shim used for local tests and small wrappers.
/// Keep intentionally tiny to avoid pulling OpenZeppelin dependencies into tests.
contract OwnableLocal {
    address private _owner;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        _owner = msg.sender;
        emit OwnershipTransferred(address(0), _owner);
    }

    modifier onlyOwner() {
    require(msg.sender == _owner, "Ownable: caller is not the owner");
        _;
    }

    function owner() public view returns (address) {
        return _owner;
    }

    function transferOwnership(address newOwner) public onlyOwner {
    require(newOwner != address(0), "Owner cannot be zero address");
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}
